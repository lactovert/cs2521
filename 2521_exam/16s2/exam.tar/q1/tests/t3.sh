./q1 3 < tests/tree1
