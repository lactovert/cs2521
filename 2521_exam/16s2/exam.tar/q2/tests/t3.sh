./q2 tests/graph1 6 2 | sort -n
