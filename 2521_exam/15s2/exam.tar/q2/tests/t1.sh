./q2 < tests/t1.in| sort
