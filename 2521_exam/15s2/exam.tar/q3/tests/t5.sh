./q3 tests/graph2 0 2 | sort -n
