./q3 tests/graph2 6 2 | sort -n
