./q3 tests/graph2 3 3 | sort -n
